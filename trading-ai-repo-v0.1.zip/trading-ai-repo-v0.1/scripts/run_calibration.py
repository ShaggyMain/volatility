"""Placeholder calibration entrypoint.

Never mutate current model weights automatically in v0.1.
Create a proposal artifact and require review/merge.
"""

if __name__ == "__main__":
    print("Calibration scaffold: no automatic weight changes in v0.1.")
