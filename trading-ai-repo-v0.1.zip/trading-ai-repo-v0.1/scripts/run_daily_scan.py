"""Placeholder orchestration entrypoint.

v0.1 intentionally separates data acquisition from scoring and resolution.
Implement providers before enabling automated scans.
"""

if __name__ == "__main__":
    print("Daily scan scaffold: providers not configured yet.")
