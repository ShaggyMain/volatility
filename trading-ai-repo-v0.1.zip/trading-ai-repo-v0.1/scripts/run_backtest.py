"""Placeholder backtest entrypoint.

Backtests must be point-in-time safe and use only data available at prediction timestamp.
"""

if __name__ == "__main__":
    print("Backtest scaffold: provider + historical data adapter required.")
