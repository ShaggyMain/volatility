# Trading AI Prediction System v0.1

A point-in-time-safe research system for earnings, volatility and catalyst-driven market predictions.

## Core design

**LLMs generate structured analytical features.** Deterministic Python code calculates final scores,
probabilities, expected value and calibration metrics. Historical predictions are immutable.

## Main engines

- Earnings Prediction
- Volatility Discovery
- Volatility Acceleration
- Catalyst Intelligence
- Sentiment Intelligence
- Options / Positioning
- Market / Sector Regime
- Direction & Asymmetry
- Backtest & Calibration

## v0.1 scope

v0.1 is research-only. It does not place trades. It focuses on reproducible predictions,
outcome resolution, scoring, and model evaluation.

## Quick start

```bash
python -m venv .venv
source .venv/bin/activate
pip install -e .
cp .env.example .env
pytest
```

## Important

Prediction files are append-only. Never use post-cutoff information in a prediction.
