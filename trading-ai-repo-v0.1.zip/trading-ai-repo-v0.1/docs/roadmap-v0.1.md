# v0.1 implementation roadmap

## Phase 1 — contracts
- [x] repository structure
- [x] AGENTS.md
- [x] prediction JSON schema
- [x] database schema
- [x] prompts
- [x] base scoring config

## Phase 2 — data adapters
- [ ] Market Chameleon adapter
- [ ] market-price adapter
- [ ] options adapter
- [ ] news adapter
- [ ] earnings calendar adapter

## Phase 3 — orchestration
- [ ] candidate pre-screen
- [ ] LLM feature extraction
- [ ] deterministic score calculation
- [ ] prediction writer

## Phase 4 — outcome resolution
- [ ] T+1/T+3/T+5 resolver
- [ ] event resolver
- [ ] outcome validation

## Phase 5 — evaluation
- [ ] metrics dashboard
- [ ] calibration plots
- [ ] setup-level analysis
- [ ] first 100/250 observation review

## Phase 6 — calibration
- [ ] proposal generator
- [ ] holdout comparison
- [ ] versioned weight changes
