from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
import json
from pathlib import Path


@dataclass(frozen=True)
class Outcome:
    actual_return_1d: float | None = None
    actual_return_3d: float | None = None
    actual_return_5d: float | None = None
    actual_event_return: float | None = None
    max_favorable_excursion: float | None = None
    max_adverse_excursion: float | None = None
    realized_volatility: float | None = None


def resolve_prediction(prediction_path: str, outcome: Outcome, out_dir: str = "predictions/resolved") -> str:
    src = Path(prediction_path)
    prediction = json.loads(src.read_text(encoding="utf-8"))

    if prediction.get("resolved_at") is not None:
        raise ValueError("Prediction already resolved; historical predictions are immutable")

    payload = {
        "prediction_id": prediction["prediction_id"],
        "resolved_at": datetime.now(timezone.utc).isoformat(),
        "outcome": outcome.__dict__,
    }

    destination = Path(out_dir) / f'{prediction["prediction_id"]}.outcome.json'
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    return str(destination)


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Resolve a prediction without modifying its original artifact.")
    parser.add_argument("prediction")
    parser.add_argument("--return-1d", type=float)
    parser.add_argument("--return-3d", type=float)
    parser.add_argument("--return-5d", type=float)
    args = parser.parse_args()
    output = resolve_prediction(
        args.prediction,
        Outcome(args.return_1d, args.return_3d, args.return_5d),
    )
    print(output)
