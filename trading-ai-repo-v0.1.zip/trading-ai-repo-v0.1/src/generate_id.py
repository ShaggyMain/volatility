from datetime import datetime, timezone
import uuid


def prediction_id(ticker: str, now: datetime | None = None) -> str:
    now = now or datetime.now(timezone.utc)
    return f"{now.strftime('%Y%m%dT%H%M%SZ')}-{ticker.upper()}-{uuid.uuid4().hex[:8]}"
