from __future__ import annotations

from pathlib import Path
from typing import Mapping
import yaml


def load_scoring_config(path: str = "config/scoring.yaml") -> dict:
    with Path(path).open("r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def weighted_score(features: Mapping[str, float], weights: Mapping[str, float]) -> float:
    available = [(k, float(features[k]), float(w)) for k, w in weights.items() if features.get(k) is not None]
    if not available:
        return 0.0
    total_w = sum(w for _, _, w in available)
    return sum(value * weight for _, value, weight in available) / total_w


def normalize_probabilities(up: float, flat: float, down: float) -> tuple[float, float, float]:
    total = up + flat + down
    if total <= 0:
        raise ValueError("Probabilities must have positive total")
    vals = (up / total, flat / total, down / total)
    return vals
