from __future__ import annotations

import json
from pathlib import Path
from jsonschema import Draft202012Validator, FormatChecker


def validate_prediction(path: str) -> None:
    schema = json.loads(Path("schemas/prediction.schema.json").read_text(encoding="utf-8"))
    instance = json.loads(Path(path).read_text(encoding="utf-8"))
    errors = sorted(Draft202012Validator(schema, format_checker=FormatChecker()).iter_errors(instance), key=str)
    if errors:
        raise ValueError("; ".join(e.message for e in errors))


if __name__ == "__main__":
    import sys
    validate_prediction(sys.argv[1])
    print("VALID")
